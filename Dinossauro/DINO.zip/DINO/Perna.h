#ifndef PERNA_H
#define PERDA_H

#include <Servo.h>

class Perna{
	public: 
	  Perna(const int &PIN_SERVO);
		void configura();
    void set(int ang);
	private: 
		int pinServo;
    Servo servo;

};

#endif
