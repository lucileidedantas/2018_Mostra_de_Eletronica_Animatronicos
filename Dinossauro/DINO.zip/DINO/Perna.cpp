#include "Perna.h"

Perna::Perna(const int &PIN_SERVO):pinServo(PIN_SERVO){}

void Perna::configura(){
  this->servo.attach(pinServo);
}

void Perna::set(int ang){
  this->servo.write(ang);
}


